---
name: giga-chart-style
description: Visual identity for matplotlib charts in Giga notebooks: Cloudflare Radar information hierarchy applied to Giga brand colours and fonts. Use when building charts in Jupyter for Giga blogs, decks, or country reports.
---

# Giga chart style — drop-in prompt

Apply this visual identity to any matplotlib chart in a Giga notebook. Information hierarchy mirrors Cloudflare Radar; colours and fonts are Giga brand.

## Header layout (single chart)

- **Title**: left-aligned, bold, fontsize 15, color `#161616`, anchored at axes-fraction `(0, 1.12)` above the plot.
- **Subtitle**: left-aligned, fontsize 10.5, color `#525252`, anchored just below the title at `(0, 1.02)`.
- **Legend**: single figure-level legend, `frameon=False`, `ncol=N`, anchored below the subtitle (or below the chart for stacked layouts).
- **Date-range footer**: right-aligned, fontsize 9, color `#525252`, at the bottom of the figure (`(0.98, 0.04)` figure-fraction).
- No top or right spines. Light dashed gridlines (`alpha=0.25–0.35`).

## Multi-panel (stacked) layout

- Figure-level title + subtitle + legend at the top, panels below.
- `plt.tight_layout(rect=[0.04, 0.04, 0.98, 0.88])` leaves a clean header band.
- `sharex=True` for time-series stacks. Major x-locator `MonthLocator()`, formatter `'%b %Y'`.

## Brand colours

```python
ON_COLOR  = '#277aff'   # Primary 600 — "good", on-net, primary series
OFF_COLOR = '#989898'   # Grey 500 — secondary, off-net, baseline
C_DARK    = '#0050e6'   # Primary 700 — emphasis line
C_LIGHT   = '#7eb0ff'   # Primary 300 — continuity / lighter series
C_ORANGE  = '#f5a623'   # accent for a third series
EVENT_BG  = '#f0f0f0'   # axvspan background for an event window
CUTOFF    = '#525252'   # vertical cutoff line color

from matplotlib.colors import LinearSegmentedColormap

# Sequential blue colormap (for heatmaps / table gradients)
giga_blues = LinearSegmentedColormap.from_list(
    'giga_blues',
    ['#eaf2ff', '#bfd7ff', '#7eb0ff', '#277aff', '#0050e6', '#002d76'])

# Single-hue red for "gap" / "blind spot" metrics (no green→red)
giga_gap = LinearSegmentedColormap.from_list(
    'giga_gap',
    ['#ffffff', '#fde2e3', '#fb9295', '#ed1c24', '#a50f17'])
```

## Typography

- Manrope on figure suptitle only; Open Sans elsewhere.
- Setup cell should monkey-patch `Figure.suptitle` to use Manrope so subplot titles stay Open Sans (preserves visual hierarchy).
- Replace unicode arrows (`→`) with en dashes (`–`) — Open Sans doesn't include `\N{RIGHTWARDS ARROW}`.

## Time-series conventions

- Aggregate to daily or weekly medians before plotting.
- Scatter alpha `0.35–0.4`, marker size `s=18`.
- OLS trendlines via `np.polyfit(x_ordinal, y, 1)`; convert x using `pd.Timestamp.toordinal` / `pd.Timestamp.fromordinal`.
- Event-window shading: `ax.axvspan(start, end, color='#f0f0f0', alpha=0.6, zorder=0)`.
- Cutoff line: `ax.axvline(cutoff, color='#525252', ls='--', lw=1, alpha=0.6)`.
- Annotation at cutoff: `ax.annotate(f'server gap: {sign}{gap:.1f} {unit}', xy=(cutoff, y_new), xytext=(8, 8), textcoords='offset points', fontsize=9.5, fontweight='bold', color='#161616')`.

## Distributions of quantized variables

Don't plot dots for variables that take ≤10 discrete values (e.g. IQB composite scores). Instead:
- Median line per group (`lw=2.4`)
- p25–p75 ribbon via `ax.fill_between(x, q25, q75, color=color, alpha=0.18, linewidth=0, zorder=2)`

## Dumbbell pattern (categorical comparisons)

For "X vs Y per category" (e.g. on-net vs off-net per area type):
- Y-axis = categories (top to bottom, `invert_yaxis()`). Include sample size in tick label: `f'{name}  (n={n})'`.
- Horizontal connector line `color='#cccccc', lw=2.5`.
- Two scatter dots, `s=140`, with brand colours.
- Gap value annotated to the right of each row.

## Heatmap pattern (3-panel: on / off / gap)

- Three side-by-side panels share the 0–100 scale.
- On-net + off-net panels use `giga_blues`.
- Gap panel uses `giga_gap` (white → brand red, no green).
- Drop colourbars; annotate cell values directly. One italic caption below the figure documents the scale.
- Text colour switches to white when value > 55 (blues) or > 50 (gap red).

## Tables (`giga_table` helper)

- MultiIndex columns for grouped metrics; vertical separators between groups via `border-left: 2px solid #989898`.
- Gradients on metric columns; white text override on cells above threshold using `.applymap` with `!important`.
- Manrope on header (12px, weight 500); Open Sans body (12px, color `#393939`); 2px Primary600 underline under the header row.

## Authoring style for accompanying prose

- Open with the event ("On October 15, …"), not the framing.
- Mark interpretation: "consistent with", "we read the gap as", "the most likely explanation".
- Short paragraphs that breathe between data and prose; charts every 200–400 words.
- Introduce charts as evidence ("Figure 1 shows…"), not illustration.
- Audience-first framing: what breaks for a student / what shapes a policy decision, not metric-first.

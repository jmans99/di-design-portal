---
name: cloudflare-radar-style
description: Style guide for analytical, data-driven writing modelled on Cloudflare Radar blog posts. Use when writing about internet trends, network events, or any data-heavy narrative that must work for both technical and general audiences.
---

Write in the style of Cloudflare Radar blog posts. Key characteristics:

**Tone and voice**
- Authoritative and factual, never sensational. State dramatic events with the same measured cadence as routine ones.
- Third-person analytical — position yourself as a neutral observer reporting what the data shows, not an opinion-giver. Use "we observed", "data shows", "Radar detected" rather than "I think" or "it's clear that."
- Technically credible without being exclusionary — the same paragraph can work for a network engineer and a curious generalist.

**Opening paragraph**
- Open with a dense, scene-setting summary that names the key findings upfront. Don't build to the point — give it in sentence one, then spend the rest of the piece explaining it.
- Use comparative context immediately: "a stark contrast to Q1 a year prior", "unlike previous quarters." Ground the reader in what's new or notable.

**Sentence rhythm**
- Alternate short declarative statements (facts) with longer compound sentences (evidence + context). Never three long sentences in a row.
- Short sentences land key findings. Long sentences carry the data and nuance.

**Data integration**
- Embed numbers directly in prose: "traffic dropped as much as 72%", "fell to 82% below expected levels." Don't relegate data to tables unless the comparison requires it.
- Technical identifiers (ASNs, IP ranges, protocol names) go in parentheses or subordinat clauses so general readers can skip them without losing the thread.
- Reference charts/graphs in prose as confirmation ("as shown in the graph below"), but write so the text stands alone without them.

**Structure**
- Use descriptive subheadings organized by theme, then geography or chronology.
- Each discrete event or finding follows this arc: Event → Timeline → Data impact → Recovery/resolution → Broader context.
- Open with a methodology or scope note when the data has known limits: "This post is intended as a summary overview... and is not an exhaustive list."

**Precision and hedging**
- Use precise qualifiers: "near-complete", "effectively zero", "reportedly", "appear to." Never overstate what the data shows.
- Distinguish clearly between what was observed (Cloudflare data) and what was officially stated (external sources, quotes). Cite sources inline.

**Conclusions**
- End with thematic synthesis, not a bullet summary. Draw the larger implication from the data: what does this quarter say about a broader trend?
- Close with a forward-looking signal — what will you continue monitoring, what should the reader watch for.
- Avoid "In conclusion" or restatement of what was just covered. Escalate to significance instead.

**What to avoid**
- No hype, no adjectives of enthusiasm ("exciting", "incredible", "groundbreaking").
- No first-person opinion ("I believe", "we think this means").
- No burying the lede — the most important finding goes in paragraph one.
- No unexplained jargon — every technical term either has a brief inline definition
  or is written so context makes it clear.

---
name: giga-di-deck-design
description: "Design system for building DI (UNICEF Digital Inclusion) and Giga slide decks — covering color, typography, slide chrome, the card system, and canonical slide types. Use this whenever the user is creating, editing, converting, or reviewing a slide deck, presentation, or slides for DI, Digital Inclusion, Giga, or any Giga product (Giga Maps, Giga Meter, Giga Sync, Giga Blocks, Giga Score, etc.) — even when they don't explicitly mention branding or a design system. DI decks default to UNICEF Blue (hex 1CABE2); Giga decks use hex 277aff."
---

# DI Deck Design System

A reference for designing slide decks under the **UNICEF Digital Inclusion (DI)** brand. Until DI's own visual identity is finalized, DI decks reuse the **Giga** design system as their base, with two overrides: the primary brand color becomes **UNICEF Blue**, and the DI logo replaces the Giga logo on cover, footer, and end slides. Everything else — type, imagery, spacing, tone, layout — stays identical to Giga.

---

## 1. Brand Architecture

- **UNICEF Digital Inclusion (DI)** — the umbrella team within UNICEF focused on expanding digital access and opportunity for young people.
- **Giga** — an initiative under DI; a joint UNICEF + ITU partnership connecting every school in the world to the internet.
  - Co-branded Giga materials must carry the **UNICEF + ITU lockup**.
  - Giga-only materials use the **standalone Giga logo**.
- **Product portfolio** (all currently use Giga visual identity): Giga Maps, Giga Maps API, Giga Meter, Giga Blocks, Giga Score, Giga Sync.
- **Evolution in progress (April 2026):** DI is developing its own naming, positioning, and visual identity. Some products will eventually migrate to DI; others will remain Giga-branded. Until DI's system ships, DI decks follow the rule below.

### DI variant rule (interim)
- Use the Giga design system as the base — type scales, pillars, imagery, tone, layout.
- **Two DI overrides:**
  1. **Color** — the primary brand color is **UNICEF Blue `#1CABE2`** (Pantone Process Cyan), used everywhere this doc otherwise calls for Primary/600.
  2. **Logo** — the **DI logo / "Digital Inclusion" wordmark** replaces the Giga logo on the cover, footer, and end slides.
- Maintain clear space around the logo — at least the height of the logo's primary glyph on all sides.
- Do not recolor, rotate, distort, or place the DI logo on busy photographic backgrounds without an overlay scrim.
- When DI content needs to credit Giga (e.g., a slide explaining Giga as a DI initiative), the **Giga logo with UNICEF + ITU lockup** appears inline within the slide body — never replacing the DI cover/footer logo.

### When to apply DI vs. Giga
- Request mentions "DI" or "Digital Inclusion" → **DI variant** (UNICEF Blue + DI logo).
- Request mentions Giga or a Giga product by name → **standard Giga** branding (`#277aff` + Giga logo).
- No brand specified → default to **Giga**.

---

## 2. Audience and Delivery Formats

The system serves two internal audiences simultaneously, and the right deliverable depends on which one is editing the file:

| Audience | Lives in | Primary deliverable | Secondary |
|---|---|---|---|
| Designers, engineers | Figma, code, AI tools | Figma source of truth | PDF for review |
| Non-tech teams (PowerPoint-fluent) | PPTX, Google Slides | Editable PPTX | Google Slides mirror |
| All audiences | — | PDF for distribution | — |

For decks specifically: **always ship an editable PPTX or Google Slides version** for non-tech teams, with the Figma source available to designers. PDFs are for read-only sharing, never the only deliverable. Embed fonts where the format allows; otherwise verify Manrope and Open Sans fall back to system-safe equivalents.

---

## 3. Design Philosophy

> "We design for human transformation, not technological display."

Visuals reveal the change that happens when students connect to learning and communities bridge divides — making complex systems feel warm, accessible, and purposeful.

### Four design pillars
- **A. People Over Technology** — show the change, not the cables; human stories front and center.
- **B. Clarity from Complexity** — turn intricate global systems into clear networks, nodes, and metaphors.
- **C. Transparent by Design** — reveal what was hidden; illuminate with light, clean lines, layered interfaces.
- **D. Globally Consistent, Locally Relevant** — flexible systems that adapt culturally without losing clarity.

### Four tone axes (all four should be present)
- **Modern and Minimal** — white space, modular grids, sans-serif, no clutter.
- **Hopeful but Credible** — warm colors, natural light, confident type, no naïve visuals.
- **Tech Precision** — crisp UI, data viz, grids, overlays.
- **Human Warmth** — rounded cards, candid photos, expressive type, texture.

---

## 4. Color System

### Primary brand color

**DI decks — default to UNICEF Blue.**
- **UNICEF Blue `#1CABE2`** (Pantone Process Cyan, RGB 28/171/226) is the DI primary. Use it everywhere this doc calls for Primary/600 — section badges, kicker labels, key emphasis words, large numerals on section dividers, default button/CTA fill, and highlighted-card outlines.
- Derive DI's lighter and darker steps consistently from UNICEF Blue: a light tint for highlighted/recommended fills (in place of Primary/100–200) and a deep shade for closing/winner surfaces (in place of Primary/900). Keep the derivation consistent across the whole deck rather than eyeballing per slide.

**Giga decks — Giga blue.**
- **#277aff** — tokenized as `Primary (Brand)/600 (Base)` in the Figma "Brand Colors" collection (or `Primary/600` in the ClickUp doc — same color).
- Full 10-step scale: `Primary/50 (#eaf2ff)` → `Primary/900 (#002d76)`.

> Whichever brand applies, the blue must be **consistent across every slide** — set it once as a token and reference it; do not hand-pick approximate blues per slide (see Known Issues).

### Neutrals
- Black `#000000`, White `#ffffff`.
- Grey scale: `Grey/50 (#fafafa)` → `Grey/950 (#161616)`.
- Use `Grey/600 (#6f6f6f)` as the neutral mid.

### Accent colors (marketing, social, print)
- **Accent Green** — base `#059669` (positive outcomes, growth, success).
- **Accent Red** — base `#ef4444` (urgency, the digital divide; use sparingly).

### Connectivity colors (product UI only — connection status)
- **Connectivity Green** `#00D661` — connected.
- **Connectivity Red** `#ED1C24` — not connected.
- **Connectivity Yellow** `#FFC93D` — fair.

### Color roles in decks
The token list isn't enough — each color has a job inside a deck. (For DI, "brand blue" below = UNICEF Blue `#1CABE2`; for Giga = `#277aff`.)

- **Brand blue (Primary/600)** — section badges, kicker labels, key emphasis words, large numerals on section dividers, default button/CTA fill.
- **Light brand tint (Primary/100–200)** — fill for highlighted/recommended rows or cards.
- **Deep brand shade (Primary/900)** — full-bleed closing slides ("Winner", "Final name"), and dark "winner" cards in decision capture slides.
- **Grey/950** — primary text on white.
- **Grey/600** — secondary body text, supporting captions, the small corner brand wordmark.
- **Grey/300** — default 1px card outline on white.
- **White** — default canvas.

> Gradients are reserved for events and campaign material — avoid in standard decks.

---

## 5. Typography

- **Primary: Manrope** — branding, hero headlines, section dividers, slide titles. Weights: **Regular & Medium** (and **SemiBold** for cover titles only).
- **Secondary: Open Sans** — body text, subtitles, kickers, captions. Weights: **Regular, Medium, SemiBold ONLY**.

> :warning: **Hard rule:** Never use Open Sans Bold — anywhere, in any size.

### Title voice rule
- Slide titles, headers, and subheaders are written in **sentence case** with **no terminal punctuation** — do not end them with a full stop.
- Examples: "Three decisions" · "Four approaches we considered" · "Two domains, three groups".
- Titles still read as confident, declarative statements — the sentence case does that work; the trailing period is dropped so titles stay clean and portable between decks.

### Type scale for decks (calibrated for 1920×1080)
| Role | Font / weight | Size |
|---|---|---|
| Cover title | Manrope SemiBold | ~110 pt |
| Section divider numeral | Manrope SemiBold, brand blue | ~110 pt |
| Section divider title | Manrope Regular, Grey/950 | ~64 pt |
| Slide title | Manrope Regular | 44–64 pt |
| Section badge / kicker | Open Sans Medium, brand blue | 14–18 pt |
| Subtitle | Manrope Regular or Open Sans Medium | 22–26 pt |
| Body | Open Sans Regular | 16–18 pt |
| Chrome (corner brand wordmark) | Open Sans Regular | 9–11 pt |
| Caption / source attribution | Open Sans Regular, Grey/600 | 9–12 pt |

These are calibrated against decks that shipped successfully — older "Display XL 144px" tier guidance overstates what a working content slide actually needs.

---

## 6. Layout & Slide Patterns

Reference templates:
- Figma slide template: https://www.figma.com/slides/Wr9twVJaKoTglaoDt8Dlll/Presentation-template?node-id=1-42
- Slide deck templates: https://www.figma.com/design/NFTLonvxQXQvzkDHEjTdsn/Slide-deck-templates?node-id=0-1

### Canvas
- **Aspect ratio:** 16:9 at **1920×1080**.
- **Margins:** generous white space; modular grid; do not crowd edges.
- **Default background:** white. Reserve the deep brand shade full-bleed for closing/winner slides only.

### Slide chrome system
Chrome is deliberately minimal so slides stay portable between presentations. Every content slide carries just **two** chrome elements, in the same fixed position:

```
┌─────────────────────────────────────────────────────────┐
│  0X · Section - Subsection                              │
│  ───── slide title and content ─────                    │
│                                                         │
│                                                         │
│                                                         │
│                                                   di    │
└─────────────────────────────────────────────────────────┘
```

- **Top-left — section badge.** Format: `0X · Section name - Subsection`, with ` · ` between number and section, and ` - ` between section and subsection. Color: brand blue. Size: 14–18 pt Open Sans Medium.
- **Bottom-right — brand wordmark.** "Digital Inclusion" for DI decks; "Giga" for Giga decks. Set **as small as possible** — minimum legible size (~9–11 pt), quiet etched/light-grey (Grey/600) treatment, tucked into the corner. It should read as a faint identity mark, never as a focal element.

**Removed from chrome (do not add these):**
- ~~Page counter (top-right `XX / NN`)~~ — removed. Slide numbers waste space and break when slides are moved between presentations.
- ~~Deck-title wordmark (bottom-left slide reference)~~ — removed, for the same reason.

**Chrome rules:**
- Section badge + small brand wordmark appear on every content slide.
- Both are omitted on the cover slide and on full-bleed closing slides (Final/Winner).
- Position is fixed across the entire deck — never nudge per slide.

### Card system
A deck should pick **one** container language and reuse it everywhere comparable content appears. The canonical container is a rounded-rectangle card.

- **Corner radius:** ~12 px at 1920×1080.
- **Interior padding:** generous; aim for 24–32 px.
- **States:**
  - **Default** — White fill, Grey/300 1 px outline, Grey/950 text.
  - **Highlighted / Recommended** — light brand tint fill, brand-blue ~1.5 px outline, optional small filled "Recommended" pill in brand blue with white text.
  - **Dark / Final** — deep brand shade fill, white text. Reserved for closing/winner cards.

### Saturation-escalation pattern (closing arc)
The end of the deck should escalate color saturation in step with certainty:
1. Working slides — white background, Grey/950 text.
2. Top picks / decision capture — **brand blue** card, white text.
3. Final / Winner — **deep brand shade** card or full-bleed, white text.

This pattern reads visually as the conversation tightening from "we're considering" to "we're committing." Use the same brand blue token throughout so the escalation stays consistent.

### Section divider spec
- White background.
- Chrome (small corner brand wordmark) present, just like content slides.
- One element on the slide: a massive **brand-blue** Manrope numeral (~110 pt) set inline with the **section title** in Grey/950 (~64 pt). Example: large blue `01` followed by black `Domain architecture`.
- No body, no decoration. The whitespace is the design.

### Source attribution
When a slide draws from another working document, place a small attribution at the bottom of the slide:
- Format: `Source: filename.docx` or `Source: [doc title]`.
- Color: Grey/600. Size: 9–12 pt Open Sans Regular.
- Position: bottom-left or bottom-right of the slide content area, above the chrome footer.

### One pattern per role
Inside a single deck, **pick one comparison container** (cards, table, or zones — not all three) and reuse it for every comparable layout. Mixing containers across slides reads as drift even if each slide is fine on its own.

### Canonical slide types
Every DI deck should be buildable from this set:

- **Cover** — Cover title (Manrope ~110 pt), date or kicker in brand blue, subtitle in Manrope/Open Sans. Chrome omitted.
- **Section divider** — Massive blue numeral + black section title. Whitespace dominant. Small corner brand wordmark present.
- **Agenda card grid** — Title ("Three decisions"), three cards across, each with a large brand-blue numeral, a Manrope sub-title, a one-line description, and a thin divider line.
- **Comparison row list (A/B/C/D)** — Title, four horizontal rows. Each row has a circular letter avatar (light brand tint fill, brand-blue letter), title + description, a Pro column, a Con column. Recommended row uses the Highlighted card state.
- **Three-column structure** — Title, three vertical columns. Each column has a kicker, big Manrope sub-title, two small product cards, divider line, and a "Why" rationale paragraph.
- **Four-card thematic grid** — Title + paragraph intro, four equal cards in a row, each with a letter, kicker, big concept name in brand blue, supporting paragraph. Optional light-tint band beneath with a one-line takeaway.
- **Table or matrix** — Clean two-column or matrix table, no heavy borders, plenty of row padding. Header row in Open Sans SemiBold; body in Regular. Use the brand scale for any data series.
- **Decision / voting capture** — Title, numbered checklist on the left, write-in slots on the right. The "Top picks" block uses the brand-blue dark card; the "Winner" block uses the deep-brand-shade dark card.
- **Closing full-bleed** — Deep brand shade background, single Manrope title centered (e.g. "Final name"), brand wordmark in the corner. Chrome omitted.
- **Quote slide** — Manrope quote in Heading LG; attribution in Open Sans Caption.
- **Stat / impact slide** — One large number in Manrope Display, supporting line in Open Sans Body, accent color used sparingly.
- **Photo slide** — Full-bleed authentic photography, Open Sans overlay caption with scrim if needed.
- **Data viz slide** — Clean grids, brand scale for series. Use Connectivity colors only when literally showing connectivity status.

---

## 7. Imagery Guidelines

- **Photography is the dominant imagery.** Use natural lighting, diverse subjects, real environments, authentic human moments.
- **Avoid:** corporate/posed/stock-looking photos, heavy filters, anything that distorts brand colors.
- **Illustrations and product-solution imagery are IN PROGRESS** — do not generate new illustration styles; reuse existing assets from the kit.
- **Product screenshots:** always current UI, minimal editing (crop or blur sensitive info only), consistent device frames, no outdated UI.
- **No-photography rule:** when a slide (or cover) doesn't include a photo, do not introduce shapes, gradients, or illustrations to fill space.

---

## 8. Known Issues / QA

- **Blue consistency.** All brand blue on a deck must come from a single token (UNICEF Blue `#1CABE2` for DI; `#277aff` for Giga). Do not hand-pick approximate blues per slide. Flagged instance: the bottom box on slides 10–12 uses an off-blue that doesn't match the rest of the deck — align these to the brand token. Before shipping, spot-check that every blue element resolves to the same value.

---

## 9. Reference Links

- **Brand & Comms Figma design system:** https://www.figma.com/design/7oQ7EAgxwBChZTMtYHj7PR/02---Brand---Comms-Design-System
- **Live brand resource site:** https://gigabrand.vercel.app/logos
- **Icons Figma library:** https://www.figma.com/design/H2tP9CwPUXLSJ4rhEPiSio/Playground
- **Product mockup Figma:** https://www.figma.com/buzz/Hay8mJDotSFrNDWcSMwOz7/Product-mockups
- **Slide template (Figma Slides):** https://www.figma.com/slides/Wr9twVJaKoTglaoDt8Dlll/Presentation-template?node-id=1-42
- **Slide deck templates (Figma):** https://www.figma.com/design/NFTLonvxQXQvzkDHEjTdsn/Slide-deck-templates?node-id=0-1
- **Giga branding kit (ClickUp):** Tech Team > Design > Branding kit (document ID: rk10z-7037).

---

## 10. Golden Rules (quick reference)

1. **Giga = UNICEF + ITU.** Never drop ITU on co-branded material.
2. **Brand blue is a fixed token** — UNICEF Blue `#1CABE2` for DI, `#277aff` for Giga. Never approximate, and keep it consistent across every slide.
3. **Manrope for titles, Open Sans for body. Never Open Sans Bold.**
4. **Titles are sentence case with no terminal full stop.**
5. **Minimal chrome** — section badge top-left, small brand wordmark bottom-right. No page numbers, no deck-title reference.
6. **One card language per deck.** Don't mix cards, tables, and zones for the same role.
7. **Saturation escalates with certainty** — white → brand blue → deep brand shade across the closing arc.
8. **People first, technology invisible.** Show outcomes, not cables.
9. **Deliver in editable formats** — PPTX/Google Slides for non-tech teams, Figma for designers.
10. **DI variant = Giga system + UNICEF Blue primary + DI logo override.** Don't invent tokens beyond those two overrides.

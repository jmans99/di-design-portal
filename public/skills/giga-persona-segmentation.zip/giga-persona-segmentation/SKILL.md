---
name: giga-persona-segmentation
description: Classifies a person into one of four school-connectivity stakeholder personas (Mandate Holder, Program Owner, Data Analyst, Implementer) with confidence-scored rationale. Use to route comms, tailor a deliverable, or understand a government/education connectivity contact.
---

Here’s a reusable, drop-in prompt you can paste into any AI to segment a person into your four personas and return clear distinctions + core definitions.

# ✅ Persona Segmentation Prompt (Giga School Connectivity Context)

You are an expert classifier for government/education-sector personas involved in school connectivity programs. Classify a described person into **exactly one** of the four personas below and return clear reasoning, confidence, and the core reference (definitions + distinguishing traits) for **all four** personas.

---

## Personas (authoritative reference)
1) **Mandate Holder**
   - **Definition:** Sets national vision, priorities, policy objectives, and budgets for school connectivity; provides oversight and demands accountability using evidence.
   - **Common org/home:** Ministers or senior leadership (MoE, MoICT, MoF), presidential taskforces/flagship digital programs, regulators, IFIs; UNICEF COs when acting as funders/governors.
   - **Decision rights:** Policy direction, funding approval/allocation, success criteria & oversight.
   - **Core jobs:** Approve/allocate funds; certify use-of-funds & outcomes; assign focal points; require evidence for policy/budget decisions; sustain high-level engagement.
   - **Distinguishers:** Talks policy/budgets/targets; signs off on money; defines success/guardrails; delegates delivery to others. **Not** doing procurement execution or field deployment.

2) **Program Owner (Designer)**
   - **Definition:** Designs and owns the digital education/connectivity program so it aligns with learning goals; prioritizes where/what to connect and specifies requirements; often drives procurement.
   - **Common org/home:** MoE program managers (national/regional), MoICT digital learning units, buyers/enablers (e.g., EITC) accountable for connectivity purchases.
   - **Decision rights:** Scope & plan; school/region prioritization; bandwidth/content/device requirements; vendor selection criteria; program reporting upward.
   - **Core jobs:** Align with education strategy; define requirements; create roll-out plan; track impact on teaching/learning; ensure readiness to report to mandate holders/funders.
   - **Distinguishers:** Speaks in “program scope, specifications, procurement, prioritization, curriculum impact.” **Not** the policy budget setter or the field deployer.

3) **Data Analyst**
   - **Definition:** Collects, validates, integrates, and analyzes connectivity/usage data to drive decisions, reporting, and continuous improvement.
   - **Common org/home:** Statistics/M&E units, ICT research centers, specialized technical arms within MoE/MoICT.
   - **Decision rights:** Data models/KPIs, validation standards, reporting/insight generation.
   - **Core jobs:** Integrate school data into national systems; analyze penetration/usage; validate KPIs; build dashboards/visuals; report value-for-money; surface gaps/underperformance.
   - **Distinguishers:** Talks “datasets, KPIs, validation, dashboards, trends.” **Not** buying connectivity or deploying networks.

4) **Implementer**
   - **Definition:** Executes connectivity rollouts and keeps schools online; manages ISPs/vendors; ensures delivery vs SLAs; troubleshoots locally.
   - **Common org/home:** Gov implementing agencies/partners; project leads of special initiatives (e.g., SmartBots); regional focal points; digital infra teams running pilots.
   - **Decision rights:** Execution plans, vendor coordination, site readiness, incident response.
   - **Core jobs:** Coordinate & execute deployments; manage ISPs/infrastructure vendors; verify contracted service levels; monitor & troubleshoot; feed implementation status back to center.
   - **Distinguishers:** Talks “rollout, installation, site readiness, SLA compliance, tickets.” **Not** the policy owner or program specifier.

---

## Inputs you will receive
Provide a **single JSON object** named `person` describing the individual. Fields may be partial; use what’s available.

```json
{
  "name": "string (optional)",
  "title_or_role": "string",
  "organization": "string",
  "unit_or_team": "string (optional)",
  "responsibilities": ["array of strings"],
  "decision_rights": ["array of strings"],
  "typical_tasks": ["array of strings (optional)"],
  "kpis_or_targets": ["array of strings (optional)"],
  "quotes_or_phrases": ["array of strings (optional)"],
  "region_context": "string (optional)"
}


⸻

Classification rules
	•	Map decision rights first, then responsibilities/tasks, then language cues.
	•	If multiple personas appear, choose the one with primary decision authority for the described scope. If still tied, choose the one most directly responsible for execution vs. design vs. oversight vs. analysis in that order:
	•	Oversight/policy/budgets → Mandate Holder
	•	Program scope/specs/prioritization/procurement → Program Owner
	•	Data integration/validation/insight/reporting → Data Analyst
	•	Field rollout/vendor mgmt/SLA verification/troubleshooting → Implementer
	•	If ambiguity remains, return top-2 with clarifying questions.

Keyword cues (non-exhaustive):
	•	Mandate Holder: policy, budget, allocate, approve, oversight, minister, regulator, taskforce, success criteria.
	•	Program Owner: program design, requirements, prioritization, procurement, curriculum alignment, roadmap, buyer.
	•	Data Analyst: datasets, KPIs, validation, dashboard, reporting, M&E, trends, integration.
	•	Implementer: rollout, deployment, ISP/vendor, site readiness, troubleshoot, SLA, NOC, field team.

⸻

Output

Return a single JSON object with:

{
  "persona": "Mandate Holder | Program Owner (Designer) | Data Analyst | Implementer",
  "confidence": 0-100,
  "rationale": "3-6 bullet points explaining the mapping to decision rights and cues.",
  "top_alternative": {
    "persona": "string or null",
    "why_not_primary": "string"
  },
  "clarifying_questions": ["array of up to 3 questions if confidence < 70"],
  "personas_reference": {
    "Mandate Holder": {
      "definition": "string",
      "distinguishers": ["..."]
    },
    "Program Owner (Designer)": {
      "definition": "string",
      "distinguishers": ["..."]
    },
    "Data Analyst": {
      "definition": "string",
      "distinguishers": ["..."]
    },
    "Implementer": {
      "definition": "string",
      "distinguishers": ["..."]
    }
  }
}


⸻

Few-shot examples

Example 1 (Mandate Holder)
Input:

{"title_or_role":"Deputy Minister for Education","organization":"Ministry of Education","responsibilities":["sets national targets","approves budgets","defines success criteria"],"decision_rights":["policy direction","budget allocation"]}

Output (abridged):

{"persona":"Mandate Holder","confidence":93,"rationale":["Budget allocation authority","Defines national success criteria","Policy direction stated"],"top_alternative":{"persona":"Program Owner (Designer)","why_not_primary":"No program-level scoping or procurement authority described"},"clarifying_questions":[],"personas_reference":{...}}

Example 2 (Program Owner)
Input:

{"title_or_role":"National Digital Learning Program Manager","organization":"MoE ICT Unit","responsibilities":["define bandwidth requirements","prioritize schools","lead procurement"],"decision_rights":["program scope","vendor selection criteria"]}

→ Persona: Program Owner (Designer)

Example 3 (Data Analyst)
Input:

{"title_or_role":"M&E Specialist","organization":"Ministry of Education","responsibilities":["integrate school data","validate KPIs","build dashboards","report progress"],"decision_rights":["KPI definitions","reporting standards"]}

→ Persona: Data Analyst

Example 4 (Implementer)
Input:

{"title_or_role":"Regional Connectivity Lead","organization":"Gov Implementing Agency","responsibilities":["coordinate ISP installations","verify SLAs at schools","troubleshoot outages"],"decision_rights":["execution plan","vendor coordination"]}

→ Persona: Implementer

⸻

Style & constraints
	•	Be concise, specific, and evidence-based from the input text.
	•	Never invent facts; when missing, lower confidence and ask clarifying questions.
	•	Always include personas_reference so the reader can see clear distinctions.

If you want, I can wrap this as a function/tool schema or tailor the examples to your countries/teams.

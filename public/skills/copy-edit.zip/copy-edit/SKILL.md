---
name: copy-edit
description: Three-step copy-editing pass (structure, content, grammar) for long-form text like blog posts, newsletters, scripts, and emails. Use when polishing a draft; run all steps or target one.
---

You are a detail-oriented copy editor.

Arguments: $ARGUMENTS

**Parse arguments:**
- If a file path is present, read that file as the source text.
- If no file path, ask the user to paste the text before proceeding.
- Step flags: `--structure` (or `1`), `--content` (or `2`), `--grammar` (or `3`).
- If no step flag is given, run all three steps in order.

---

## Step 1 — Structure
*Run if: no flag, or `--structure` / `1`*

Analyze logical order and coherence.
- Flag sections that are out of order or would read better repositioned.
- Identify gaps where a transition, setup, or landing is missing.
- For each issue: state the problem, explain why it weakens the piece, and show a concrete fix or rewrite.

---

## Step 2 — Content
*Run if: no flag, or `--content` / `2`*

Analyze specificity, point of view, and reader value.
- Flag where the text is vague, generic, or tells instead of shows.
- Identify opportunities to add concrete detail: a statistic, example, story, counterpoint, or lesson.
- For each opportunity: name the upgrade type (e.g. "add example", "sharpen claim"), explain the logic, and show what it could look like.

---

## Step 3 — Grammar
*Run if: no flag, or `--grammar` / `3`*

Conduct a close grammatical pass. Flag and quote each instance of:
- Misspelled words
- Passive voice
- Incomplete, run-on, or confusing sentences

Group by category. For each: quote the original, state the issue, suggest a fix.

---

After completing the requested step(s), ask if the user wants to move to the next one (if any remain).

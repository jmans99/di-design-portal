---
name: giga-design-system
description: Build product UI in the Giga Product Design System — Manrope/Open Sans type, the Giga colour palette, shadcn/ui + Tailwind tokens, radii, shadows, and spring motion. Use when building or styling a Next.js/React product so it is on brand by construction.
---

# Giga Product Design System

Use the content below as system instructions or custom instructions in your vibecoding tool (Cursor, Claude, Lovable, etc.).

You are building a product using the Giga Product Design System. Every UI element MUST follow these rules exactly. Use shadcn/ui components (vanilla, installed via npx shadcn@latest add) with Giga token customization applied through CSS variables and Tailwind config. Stack: Next.js + React + Tailwind CSS + shadcn/ui.

FONTS — Only two allowed, no exceptions:
Manrope → headings (text-2xl to text-9xl), weight 500 only
Open Sans → everything else (text-xs to text-xl), weights: 400, 500, 600
Import: @import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Open+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&display=swap');

FONT WEIGHT RULES:
400 Regular → Body text, paragraphs, descriptions
500 Medium → Interactive elements (buttons, links, tags)
600 Semibold → Section titles, leading headers

TYPOGRAPHY SCALE:
Headings (Manrope 500): text-9xl:128/136/-1px | text-8xl:96/104 | text-7xl:72/80 | text-6xl:60/68 | text-5xl:48/56 | text-4xl:36/42 | text-3xl:30/36 | text-2xl:24/36
Body (Open Sans 400/500/600): text-xl:20/30 | text-lg:18/28 | text-base:16/24 | text-sm:14/20 | text-xs:12/18

COLORS:
Primary: 50:#eaf2ff 100:#d4e5ff 200:#bfd7ff 300:#a9caff 400:#7eb0ff 500:#5495ff 600:#277aff(BASE) 700:#0050e6 800:#002d9c 900:#002d76
Grey: 50:#fafafa 100:#f4f4f4 200:#e9e9e9 300:#dfdfdf 400:#cacaca 500:#989898 600:#6f6f6f 700:#525252 800:#393939 900:#161616 950:#161616
Base: Black:#000000 White:#ffffff
Connectivity: Green600:#00d661(good) | Yellow:#ffc93d(moderate) | Red:#ed1c24(bad)
Green scale: 50:#d6ffe9 100:#adffd2 200:#85ffbc 300:#5cffa5 400:#33ff8f 500:#0aff78 600:#00d661 700:#00b853 800:#008f40 900:#00662e

LIGHT MODE: Text primary:Grey950 | Text secondary:Grey600 | Icons primary:Grey950 | Icons secondary:Grey600 | Background:White | Dividers default:Grey200 light:Grey100 | Primary btn: fill Primary600 hover:Primary700 text:White | Secondary btn: outline Primary600 hover:Primary700 | Link:Primary600
DARK MODE (Giga Maps): Text primary:Grey50 | Text secondary:Grey400 | Icons primary:Grey50 | Icons secondary:Grey400 | Background:Grey950 | Dividers default:Grey800 light:Grey900 | Buttons same as light | Link:Primary600

CSS VARIABLES (globals.css):
:root { --background:0 0% 100%; --foreground:0 0% 9%; --card:0 0% 100%; --card-foreground:0 0% 9%; --popover:0 0% 100%; --popover-foreground:0 0% 9%; --primary:214 100% 58%; --primary-foreground:0 0% 100%; --secondary:0 0% 96%; --secondary-foreground:0 0% 9%; --muted:0 0% 91%; --muted-foreground:0 0% 44%; --accent:214 100% 95%; --accent-foreground:0 0% 9%; --destructive:357 88% 52%; --destructive-foreground:0 0% 100%; --border:0 0% 91%; --input:0 0% 91%; --ring:214 100% 58%; --radius:6px; }
.dark { --background:0 0% 9%; --foreground:0 0% 98%; --card:0 0% 9%; --card-foreground:0 0% 98%; --popover:0 0% 9%; --popover-foreground:0 0% 98%; --primary:214 100% 58%; --primary-foreground:0 0% 100%; --secondary:0 0% 9%; --secondary-foreground:0 0% 98%; --muted:0 0% 22%; --muted-foreground:0 0% 79%; --accent:0 0% 22%; --accent-foreground:0 0% 98%; --destructive:357 88% 52%; --destructive-foreground:0 0% 100%; --border:0 0% 22%; --input:0 0% 22%; --ring:214 100% 58%; }

BORDER RADIUS: Small card:6px | Big card:8px | Badge:4px | Small btn:4px | Standard btn:6px | Pill btn:9999px | Inputs:6px
SHADOWS: shadow→form controls | shadow-sm→small cards | shadow-md→medium cards | shadow-lg→dropdowns,tooltips | shadow-xl→modals,dialogs | shadow-2xl→fullscreen overlays | shadow-inner→focused inputs
HOVER RULE: All interactive elements go UP one shadow step on hover.
MOTION: Medium/large: spring(mass:1,stiffness:180,damping:30) ~400ms | Small: spring(mass:1,stiffness:720,damping:60) ~200ms

COMPONENTS (install via npx shadcn@latest add): Button, Input, Card, Dialog, Table, Tabs, Select, Form, Sidebar, Navigation Menu, Sheet, Badge, Toast (Sonner), Tooltip, Charts (Recharts)

RULES: 1) Only Manrope+Open Sans 2) shadcn/ui vanilla themed via CSS vars 3) Next.js+React+Tailwind 4) Only Giga palette colors 5) Shadow up on hover 6) Border radius per component table 7) Spring animations
